YRT Music v1.0 source | YRT-GPT

Official release date: 2026-10-31 (Asia/Shanghai).
GitHub tag: v1.0; application version: 1.0.0.0.

From this Source directory, run:
  powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -OutputDirectory .\Build

The Windows .NET Framework x64 C# compiler builds src/ and generates the release date from release.json.
No package download or additional SDK is required. This build is unsigned.
Optional signing helpers are in tools/signing/. No private key is included.
Release-date checks and policy are in tools/release/ and docs/ReleasePolicy.md.

The date correction does not change search, matching, download or font behavior. MIT licensed.
