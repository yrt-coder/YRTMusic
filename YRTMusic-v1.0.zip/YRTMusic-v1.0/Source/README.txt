YRT Music v1.0 source | YRT-GPT

From this Source directory, run:
  powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -OutputDirectory .\Build

The Windows .NET Framework x64 C# compiler builds the four C# files in src.
No package download or additional SDK is required. The generated executable is
unsigned. The signing scripts are provided separately and require a local code
signing certificate; no private key is included.

This is the historical v1.0 application. The October 31, 2026 revision removes
the signature-information UI and adds a brief Help > About dialog. Search,
automatic matching, download behavior and font choices retain the v1.0 code.
The original v1.0 date is October 23, 2026. The software is MIT licensed.
