# YRT Music 源码

正式发布日期：2026-10-31（Asia/Shanghai）。

在本目录运行 `powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -OutputDirectory .\Build`。

日期来自 release.json；发布检查见 docs/ReleasePolicy.md。
